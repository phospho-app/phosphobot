# Contributing to MoveIt

Thanks for getting involved! Information on contributing can be found at
[http://moveit.ros.org/documentation/contributing/](http://moveit.ros.org/documentation/contributing/)
