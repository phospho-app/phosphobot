Please consult tutorials and the official [documentation](https://moveit.ros.org/documentation/concepts/).

For details about the blend algorithm please refer to
![doc/MotionBlendAlgorithmDescription.pdf](doc/MotionBlendAlgorithmDescription.pdf).
